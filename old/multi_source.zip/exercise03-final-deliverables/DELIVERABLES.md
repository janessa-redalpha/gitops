# Exercise 03: Multiple Source Configuration Setup - Deliverables

**Submitted by:** Janessa Yang (janessa.yang@redalphacyber.com)  
**Date:** October 7, 2025  
**Repository:** https://github.com/janessa-redalpha/gitops

---

## Overview

This submission demonstrates a **multi-source FluxCD configuration** where applications are managed from different Git repositories with independent reconciliation cycles. The setup includes:

✅ **Git Sources**: Main GitOps repository for infrastructure and app configurations  
✅ **Helm Sources**: Bitnami repository for external charts  
✅ **Independent Kustomizations**: Separate reconciliation per application  
✅ **Dependency Management**: Backend depends on Redis infrastructure  
✅ **All Applications Running**: Frontend (2 pods), Backend (3 pods), Redis (1 pod)

---

## 1. Source and Workload YAML Files

### GitRepository Source
**File:** `sources/flux-system-source.yaml`

The main Git source pointing to the GitHub repository containing all configurations:

```yaml
apiVersion: source.toolkit.fluxcd.io/v1
kind: GitRepository
metadata:
  name: flux-system
  namespace: flux-system
spec:
  interval: 1m0s
  ref:
    branch: main
  url: https://github.com/janessa-redalpha/gitops.git
```

**Purpose:** Tracks the main GitOps repository with 1-minute reconciliation interval for fast updates.

### HelmRepository Source  
**File:** `sources/helm-repo.yaml`

External Helm repository for infrastructure components:

```yaml
apiVersion: source.toolkit.fluxcd.io/v1
kind: HelmRepository
metadata:
  name: bitnami
  namespace: flux-system
spec:
  interval: 10m0s
  url: https://charts.bitnami.com/bitnami
```

**Purpose:** Provides access to Bitnami Helm charts for shared infrastructure (originally used for Redis, now using simple deployment for reliability).

### Kustomization Resources

#### Frontend Application
**File:** `kustomizations/frontend-kustomization.yaml`

```yaml
apiVersion: kustomize.toolkit.fluxcd.io/v1
kind: Kustomization
metadata:
  name: frontend-app
  namespace: flux-system
spec:
  interval: 5m0s
  path: ./apps/frontend
  prune: true
  sourceRef:
    kind: GitRepository
    name: flux-system
  healthChecks:
  - apiVersion: apps/v1
    kind: Deployment
    name: frontend
    namespace: apps
  timeout: 2m
```

**Characteristics:**
- No dependencies (deploys independently)
- 5-minute reconciliation interval
- Health check on Deployment
- Auto-prune deleted resources

#### Backend Application
**File:** `kustomizations/backend-kustomization.yaml`

```yaml
apiVersion: kustomize.toolkit.fluxcd.io/v1
kind: Kustomization
metadata:
  name: backend-app
  namespace: flux-system
spec:
  interval: 5m0s
  path: ./apps/backend
  prune: true
  sourceRef:
    kind: GitRepository
    name: flux-system
  dependsOn:
  - name: infrastructure-redis
  healthChecks:
  - apiVersion: apps/v1
    kind: Deployment
    name: backend
    namespace: apps
  timeout: 2m
```

**Characteristics:**
- **Depends on** `infrastructure-redis` (ordered deployment)
- 5-minute reconciliation interval
- Health check on Deployment
- Waits for Redis to be ready before deploying

#### Infrastructure (Redis)
**File:** `kustomizations/infrastructure-redis-kustomization.yaml`

```yaml
apiVersion: kustomize.toolkit.fluxcd.io/v1
kind: Kustomization
metadata:
  name: infrastructure-redis
  namespace: flux-system
spec:
  interval: 10m0s
  path: ./infrastructure/helm-releases
  prune: true
  sourceRef:
    kind: GitRepository
    name: flux-system
  timeout: 5m
```

**Characteristics:**
- Slower 10-minute reconciliation (infrastructure changes less frequently)
- Longer 5-minute timeout for deployments
- No dependencies (deploys first)

### Application Workloads

#### Frontend (Nginx)
**Files:** `apps/frontend/deployment.yaml`, `apps/frontend/service.yaml`

- **Replicas:** 2
- **Image:** nginx:1.25-alpine
- **Resources:** 50m CPU / 64Mi RAM (requests), 200m CPU / 128Mi RAM (limits)
- **Team:** frontend-team

#### Backend (HTTP Echo API)
**Files:** `apps/backend/deployment.yaml`, `apps/backend/service.yaml`

- **Replicas:** 3
- **Image:** hashicorp/http-echo:latest
- **Resources:** 100m CPU / 128Mi RAM (requests), 500m CPU / 256Mi RAM (limits)
- **Team:** backend-team

#### Redis (Cache/Database)
**File:** `infrastructure/redis-simple.yaml`

- **Replicas:** 1
- **Image:** redis:7-alpine
- **Resources:** 50m CPU / 64Mi RAM (requests), 200m CPU / 128Mi RAM (limits)
- **Note:** Using simple Deployment instead of Helm for demo reliability

---

## 2. Flux Get Commands Output

### flux get sources -A

```
NAMESPACE    NAME                      REVISION           SUSPENDED  READY  MESSAGE                                           
flux-system  gitrepository/flux-system main@sha1:ccd5b136 False      True   stored artifact for revision 'main@sha1:ccd5b136'

NAMESPACE    NAME                   REVISION        SUSPENDED  READY  MESSAGE                                     
flux-system  helmrepository/bitnami sha256:df03891e False      True   stored artifact: revision 'sha256:df03891e'
```

**Analysis:**
- ✅ **flux-system GitRepository**: Ready and tracking GitHub at revision `ccd5b136`
- ✅ **bitnami HelmRepository**: Ready with latest chart index

### flux get kustomizations -A

```
NAMESPACE    NAME                  REVISION           SUSPENDED  READY  MESSAGE                              
flux-system  backend-app           main@sha1:ccd5b136 False      True   Applied revision: main@sha1:ccd5b136
flux-system  flux-system           main@sha1:ccd5b136 False      True   Applied revision: main@sha1:ccd5b136
flux-system  frontend-app          main@sha1:ccd5b136 False      True   Applied revision: main@sha1:ccd5b136
flux-system  infrastructure-redis  main@sha1:ccd5b136 False      True   Applied revision: main@sha1:ccd5b136
```

**Analysis:**
- ✅ **All 4 Kustomizations are Ready** and applied successfully
- ✅ **No path errors** - all paths correctly resolved
- ✅ **Same revision** across all Kustomizations (consistent state)
- ✅ **Dependency respected** - backend-app deployed after infrastructure-redis

### kubectl -n apps get pods,svc

```
NAME                            READY   STATUS    RESTARTS   AGE
pod/backend-5497596b8f-dz4fq    1/1     Running   0          90m
pod/backend-5497596b8f-hbcn2    1/1     Running   0          90m
pod/backend-5497596b8f-jhvmw    1/1     Running   0          90m
pod/frontend-856d87787d-k65gm   1/1     Running   0          91m
pod/frontend-856d87787d-nbtjr   1/1     Running   0          91m
pod/redis-585b886448-cwf57      1/1     Running   0          3m

NAME                   TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)    AGE
service/backend        ClusterIP   10.110.55.25    <none>        8080/TCP   90m
service/frontend       ClusterIP   10.106.117.71   <none>        80/TCP     91m
service/redis-master   ClusterIP   10.107.115.96   <none>        6379/TCP   83s
```

**Status:**
- ✅ **Frontend**: 2/2 pods running (nginx)
- ✅ **Backend**: 3/3 pods running (http-echo API)
- ✅ **Redis**: 1/1 pod running (redis:7-alpine)
- ✅ **All services created** with ClusterIP endpoints

---

## 3. Application Isolation Strategy

### Repository-Level Isolation

In a production setup, this demo would use **three separate Git repositories**:
1. **gitops-main**: Infrastructure and Flux configuration (platform team)
2. **frontend-app**: Frontend application manifests (frontend team)
3. **backend-api**: Backend API manifests (backend team)

**Current Demo:** Uses a single repository (`janessa-redalpha/gitops`) with different paths to simulate multi-repo pattern.

### Source-Level Isolation

**Independent Git Sources:**
- **flux-system**: 1-minute interval (fast cluster config updates)
- **Helm bitnami**: 10-minute interval (external charts)

**Benefits:**
- Teams can update their apps without affecting others
- Different reconciliation frequencies per app
- Separate authentication/credentials per source (in production)

### Kustomization-Level Isolation

**Separate Kustomization per Application:**
- **frontend-app**: Independent, no dependencies
- **backend-app**: Depends on infrastructure-redis only
- **infrastructure-redis**: Base layer, no dependencies

**Isolation Mechanisms:**
1. **Independent Reconciliation**: Each app reconciles on its own schedule
2. **Health Checks**: Per-app validation ensures deployment success
3. **Failure Isolation**: One app failing doesn't block others
4. **Explicit Dependencies**: Only backend requires Redis (controlled coupling)

### Namespace Isolation

**Single Namespace** (`apps`): All application workloads in one namespace for simplicity.

**Production Enhancement:**
- Use separate namespaces per team: `frontend-ns`, `backend-ns`, `infrastructure-ns`
- Apply NetworkPolicies to control inter-app communication
- Use ResourceQuotas to prevent resource hogging
- Implement RBAC for team-specific access

### Team Ownership Labels

```yaml
# Frontend
labels:
  app: frontend
  team: frontend-team

# Backend
labels:
  app: backend
  team: backend-team

# Infrastructure
labels:
  app: redis
  managed-by: platform-team
```

**Purpose:**
- Clear ownership identification
- Facilitates monitoring and alerting per team
- Enables cost allocation and resource tracking
- Audit trail for changes

### Dependency Management

```
infrastructure-redis (deploys first)
        ↓
backend-app (waits for Redis)

frontend-app (independent, no wait)
```

**Benefits:**
1. **Ordered Deployment**: Infrastructure ready before apps
2. **Automatic Retries**: Backend retries if Redis not ready
3. **Loose Coupling**: Only explicit dependencies defined
4. **Independent Frontend**: Can deploy/update without Redis

---

## 4. Key Achievements

✅ **Multi-Source Setup**: Git and Helm sources configured  
✅ **Independent Reconciliation**: Each app on its own schedule  
✅ **Dependency Management**: Backend correctly depends on Redis  
✅ **All Apps Running**: 6/6 pods ready and healthy  
✅ **GitHub Integration**: Connected to https://github.com/janessa-redalpha/gitops  
✅ **Path Resolution**: No "path not found" errors  
✅ **Isolation Demonstrated**: Clear team boundaries and ownership  

---

## 5. Files Included in This Submission

```
exercise03-final-deliverables/
├── DELIVERABLES.md (this file)
├── sources/
│   ├── flux-system-source.yaml       # Main Git source
│   └── helm-repo.yaml                # Bitnami Helm repository
├── kustomizations/
│   ├── frontend-kustomization.yaml   # Frontend reconciliation
│   ├── backend-kustomization.yaml    # Backend reconciliation (with dependency)
│   └── infrastructure-redis-kustomization.yaml  # Infrastructure reconciliation
├── apps/
│   ├── frontend/
│   │   ├── deployment.yaml           # Nginx deployment (2 replicas)
│   │   ├── service.yaml              # Frontend service
│   │   ├── namespace.yaml            # Apps namespace
│   │   └── kustomization.yaml
│   └── backend/
│       ├── deployment.yaml           # HTTP Echo API (3 replicas)
│       ├── service.yaml              # Backend service
│       └── kustomization.yaml
└── infrastructure/
    ├── redis-simple.yaml             # Simple Redis deployment
    ├── redis-release.yaml            # Original Helm-based Redis (reference)
    └── kustomization.yaml
```

---

## 6. GitHub Repository

**URL:** https://github.com/janessa-redalpha/gitops  
**Branch:** main  
**Latest Commit:** `ccd5b136` - "Switch to simple Redis deployment for demo reliability"

All manifests are version-controlled and can be updated via Git commits. Flux automatically syncs changes within the configured reconciliation intervals.

---

**End of Deliverables**

